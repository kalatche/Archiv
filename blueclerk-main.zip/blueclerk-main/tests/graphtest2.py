import networkx as nx
import matplotlib.pyplot as plt

#create graph
G = nx.Graph()

#create nodes
G.add_node(1)
G.add_node(2)
G.add_node(3)

# create edges
G.add_edge(1,2)
G.add_edge(1,3)

# Information
print(G.number_of_nodes())
print(G.number_of_edges())

print(list(G.nodes))
print(list(G.edges))

# drawing
#nx.draw(G)
nx.draw(G, with_labels=True)
plt.savefig("test.png")