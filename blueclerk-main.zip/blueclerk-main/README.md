# BlueClerk

## System-Requirements
python3<br>
python3-pip<br> 
linux/wsl<br>

## virtual environment
. venv/bin/activate


## Install
python3 -m pip install -r requirements.txt

## Start
export FLASK_APP = init.py
python3 -m flask run

dj: python3 manage.py runserver
dj: python3 manage.py runserver 0:8080

##debug
export FLASK_APP = development
flask run

## db
dj: python3 manage.py makemigrations 'app' //make changes
dj: python3 manage.py migrate //apply changes
dj: python3 manage.py sqlmigrate 'app' 'version' // sql scheme

## information
dj: python3 manage.py check
dj: python3 manage.py shell

## Errors/Notes

## Packets
pygraphviz (apt und pip)
matplotlib
networkx
pydot

## Sources
https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-iii-web-forms
https://www.d3-graph-gallery.com/network
https://andrewmellor.co.uk/blog/articles/2014/12/14/d3-networks/
https://pygraphviz.github.io/documentation/stable/install.html
https://networkx.org/documentation/stable/tutorial.html
https://www.digitalocean.com/community/tutorials/how-to-make-a-web-application-using-flask-in-python-3-de
https://memgraph.com/blog/how-to-visualize-a-social-network-in-python-with-a-graph-database