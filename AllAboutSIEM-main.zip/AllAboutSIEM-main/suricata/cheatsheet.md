### Suricata Rules

## Rule Structure
alert tcp $EXTERNAL_NET any -> any 3389 (msg:"ET POLICY Inbound RDP Connection with Minimal Security Protocol Requested"; flow:established,to_server; content:"|00 00|"; offset:1; depth:2; content:"|e0|"; distance:2; within:1; content:"|01 00 08 00 00 00 00 00|"; within:15; fast_pattern; endswith; reference:url,medium.com/@bromiley/what-happens-before-hello-ce9f29fa0cef; classtype:bad-unknown; sid:2027413; rev:3; metadata:affected_product Windows_XP_Vista_7_8_10_Server_32_64_Bit, created_at 2019_05_31, deployment Perimeter, former_category POLICY, performance_impact Low, signature_severity Major, updated_at 2020_08_19;)

- **action** : "alert" 
- **header** : "tcp $EXTERNAL_NET any -> any 3389"  
- **option** : (msg:"ET POLICY Inbound RDP Connection with Minimal Security Protocol Requested"; flow:established,to_server; content:"|00 00|"; offset:1; depth:2; content:"|e0|"; distance:2; within:1; content:"|01 00 08 00 00 00 00 00|"; within:15; fast_pattern; endswith; reference:url,medium.com/@bromiley/what-happens-before-hello-ce9f29fa0cef; classtype:bad-unknown; sid:2027413; rev:3; metadata:affected_product Windows_XP_Vista_7_8_10_Server_32_64_Bit, created_at 2019_05_31, deployment Perimeter, former_category POLICY, performance_impact Low, signature_severity Major, updated_at 2020_08_19;) 

### action
self-explanatory: alert, pass, drop, reject....

### header
- Protocol (layer4): tcp/udp
- Protocl (layer"7"): http, ftp, icmp,rdp,dhcp,modbus and so on
- SourceIP SourcePort (and) DestinationIP SourcePort 
- directions:-> (Only To), <- (Only from) <> (All)

### option 
- enclosed by parenthesis ()
- seperated by semicolons ;
- keyword:settings; keyword;
- content modifiers: (content:"XY"; http_uri;sid:1;) | pattern XY modified to inspect http_uri buffer
- sticky buffer: (http_response_line; content:"403 Forbidden") | "403.." inspect against http_response_line

## Rule Tags
### rule description
msg: Description

### rule base
flow:established 
 - Match on established connections

to_server
 - zielsystem

content
 - what should be match
 - content match on bytes [0-255]
 - case sensitiv
 - \|| pipes to escape

offset
 - from which byte will be checked
 - the from (from X to Y)
 - see examples

depth
 - comes after content
 - Number: how many bytes from beginning of payload will be checked
 - the to (from X to Y)
 - see examples

distance
 - relativ content modifier, connect to last content
 - take last match and look X bytes after this for new content-match
 - The offset after a match keyword

within
 - relativ content modfier, connect to last content
 - take last match and go maxim X bytes ahead for matches
 - the depth after a match keyword
 - ??? not complete clear (see hack to pieces dist2, within1)

fast_pattern
 - manipulate the Multi Pattern Matcher (MPM) to use this one as "theMain"
 - ??? not complete clear

endswith
 - must follow content
 - exactly match the end of buffer

flags
 - check specific tcp flags
 - S:SYN, F:FIN, R:RST, P:PSH A:ACK, U:URG
 - Check reserved bytes 0 (no), 1byte, 2bytes

threshold
 - control ert frequency, set a minimum threshold before generate alerts
 - type both: combination of threshold and limit, combined with count/seconds alerts only once in this range
 - type limit: alert limit only all XY times

track
 - tracking specific value
 - track: by_src (track by IP)

count
 - number of alert counts

seconds
 - time period the count needs to activate

### rule meta
- referenz: type,referenz 
- classtype: kind of, classification
- sid: signatureID (just a number)
- rev: revision (version of sid, modified state)
- metadata: non-functional information

### Examples
content:"def"; offset:3;depth:3;
 - look for def from the third byte till the sixth byte
 - "abcdefghij" -> abc(no) def (yes) ghij (no)

### Reference
- https://suricata.readthedocs.io/en/suricata-6.0.0/rules/intro.html
- https://www.mcafee.com/blogs/other-blogs/mcafee-labs/rdp-security-explained/
- https://bromiley.medium.com/what-happens-before-hello-ce9f29fa0cef
- https://redmine.openinfosecfoundation.org/projects/suricata/wiki/Fast_Pattern
- https://redmine.openinfosecfoundation.org/projects/suricata/wiki/Suricata_Fast_Pattern_Determination_Explained
- http://www.countersnipe.com/support/cs-writing-rules.pdf
