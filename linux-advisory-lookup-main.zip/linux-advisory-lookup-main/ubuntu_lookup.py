#!/usr/bin/python
# -*- coding: <encoding name> -*-
__author__ = "Daniel Fanderl"
__email__ = "daniel.fanderl@lew-verteilnetz.de"

import json
import requests

# Comment
def pull_ubuntu() -> list:
    print("Funktion: IM UBUNTU Pullinger!")
    print("------------------------------")

    limit=3
    url = 'https://ubuntu.com/security/notices.json?limit='+str(limit)


    # limit max 100
    json_req = requests.get(url)
    data = json.loads(json_req.content)

    # get each cve
    relevant_notices = []
    for note in data['notices']:
        
        # releases=[]
        releases = ""
        # get package 
        for distro in note['releases']:
            #releases.append("Ubuntu " +distro['codename']+" "+distro['support_tag']+" "+distro['version'])
            releases = releases + ("Ubuntu " +distro['codename']+" "+distro['support_tag']+" "+distro['version'] + ", ")
 
        # get cvss
        vulns = []
        for cve in note['cves']:
            des = ''.join(cve['description'].split('\n'))
            des = des.replace(";",".")

            #vulns.append([cve['id'],cve['published'], str(cve['cvss3']), des, releases])
            vulns.append([cve['id'],cve['published'], str(cve['cvss3']), des])
             
        for vuln in vulns:
            relevant_notices.append(vuln)

    return relevant_notices