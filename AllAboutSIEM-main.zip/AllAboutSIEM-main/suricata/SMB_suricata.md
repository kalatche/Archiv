# Suricata for SMB
## ET POLICY SMB2 NT Create AndX Request For an Executable File In a Temp Directory 
alert tcp any any -> $HOME_NET 445 (msg:"ET POLICY SMB2 NT Create AndX Request For an Executable File In a Temp Directory"; flow:established,to_server; content:"SMB"; depth:8; content:"|05 00|"; distance:8; within:2; content:"t|00|e|00|m|00|p|00|\\|00|"; nocase; distance:0; content:"|00 2E 00|e|00|x|00|e|00|"; nocase; distance:0; classtype:trojan-activity; sid:2025703; rev:2; metadata:affected_product Windows_XP_Vista_7_8_10_Server_32_64_Bit, attack_target SMB_Client, created_at 2018_07_16, deployment Internal, former_category POLICY, signature_severity Minor, updated_at 2018_07_16;)

### hacked to pieces
SMB established Connections to server 

content:"SMB"; depth:8;
- check 8 bytes for "SMB" 

content:"|05 00|"; distance:8; within:2; 
- next 2 bytes from distance 8 from previsious match)
- "create Request File"

content:"t|00|e|00|m|00|p|00|\\|00|"; nocase; distance:0; 
- find from previsious (05 00) result, a "\*temp\\" patter
- t = 74, e = 65, 6d = m, 70 = p

content:"|00 2E 00|e|00|x|00|e|00|"; nocase; distance:0; 
- 2e = . , 65 = e, 78 = x 

### notes
- Triggers on all SMB-Events with a Path like: \*temp\\\*.exe
- Ex. Software distribution over SCCM or File-Server transfers 

### matched on
SMB2 Datapacket:

|bytes | data|
|-----|-------------------------------------------------|
| 0000 |  fe **53 4d 42** 40 00 01 00 00 00 00 00 05 00 61 00 |
| 0010 |  08 00 00 00 00 00 00 00 2b 00 00 00 00 00 00 00 |
| 0020 |  ff fe 00 00 **05 00** 00 00 19 00 00 80 00 14 00 00 |
| 0030 |  6c c5 de d7 fc 2d c1 7d 1f 7e c5 9c 77 5f 4d 4f |
| .. |  .. |
| 00d0 |  74 00 5f 00 73 00 65 00 74 00 75 00 70 **00 2e 00** |
| 00e0 |  **65 00 78 00 65 00** 00 00 38 00 00 00 10 00 04 00 |
| 00f0 |  ... |



## ET POLICY Executable and linking format (ELF) file download
rule.rule.security: alert tcp $EXTERNAL_NET !$HTTP_PORTS -> $HOME_NET any (msg:"ET POLICY Executable and linking format (ELF) file download"; flow:established; content:"|7F|ELF"; fast_pattern; content:"|00 00 00 00 00 00 00 00|"; distance:0; flowbits:set,ET.ELFDownload; reference:url,www.itee.uq.edu.au/~cristina/students/david/honoursThesis96/bff.htm; reference:url,doc.emergingthreats.net/bin/view/Main/2000418; classtype:policy-violation; sid:2000418; rev:16; metadata:created_at 2010_07_30, updated_at 2017_02_03;)

### hacked to pieces
content:"|7F|ELF"; fast_pattern; 
- 
content:"|00 00 00 00 00 00 00 00|"; distance:0; flowbits:set,ET.ELFDownload; 


### notes
### matched on

## references
