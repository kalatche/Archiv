## SMB

**Check default Admin Folders**
- event.dataset:smb* AND file.path.keyword:(*\\C$* AND  *ADMIN$* OR *IPC$*) AND (NOT file.name:*tmp)

**Check for Runables (exe, ps1)**
- event.dataset:smb* AND (file.name:\*exe OR file.name:\*ps1)
