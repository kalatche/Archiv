# Suricata for RDP
## ET POLICY Inbound RDP Connection with Minimal Security Protocol Requested
rule: 
alert tcp $EXTERNAL_NET any -> any 3389 (msg:"ET POLICY Inbound RDP Connection with Minimal Security Protocol Requested"; ***flow:established,to_server; content:"|00 00|"; offset:1; depth:2; content:"|e0|"; distance:2; within:1; content:"|01 00 08 00 00 00 00 00|"; within:15; fast_pattern; endswith;*** reference:url,medium.com/@bromiley/what-happens-before-hello-ce9f29fa0cef;classtype:bad-unknown; sid:2027413; rev:3; metadata:affected_product Windows_XP_Vista_7_8_10_Server_32_64_Bit, created_at 2019_05_31, deployment Perimeter, former_category POLICY, performance_impact Low, signature_severity Major, updated_at 2020_08_19;)

### hacked to pieces
content:"|00 00|"; offset:1; depth:2;
 - Look for 2 zero bytes from the second to third bytes

content:"|e0|"; distance:2; within:1;
 - look for e0, start two byte after and end 1 byte behind last (content) match 
 - !!ERROR!! Does it mean, go 2 ahead an match 1 byte??

content:"|01 00 08 00 00 00 00 00|"; within:15; fast_pattern; endswith;
 - look for the pattern in the next 15 it must end with this pattern

### matched on
|bytes | data|
|-----|-------------------------------------------------|
|0000 |  00 50 56 a5 3d fd 00 1c 7f 6d ac 1e 08 00 45 00|
|0010 |  00 3b b8 71 40 00 7f 06 d1 69 c1 17 4f 14 c0 a8|
|0020 |  a1 0d 0d 3d dd 48 9b 43 20 31 7c 55 7c f7 50 18|
|0030 |  f9 ed 80 7f 00 00 ***03 00 00 13 0e d0 00 00 12 34***|
|0040 |  ***00 03 00 08 00 01 00 00 00***|

- Matched on the TLS Packet (wrapped by tcp)
- Means RDP Security (bad one -> further investigation needed)


## ET SCAN Behavioral Unusually fast Terminal Server Traffic Potential Scan or Infection (Inbound)
alert tcp $EXTERNAL_NET any -> $HOME_NET 3389 (msg:"ET SCAN Behavioral Unusually fast Terminal Server Traffic Potential Scan or Infection (Inbound)"; flow:to_server; flags: S,12; threshold: type both, track by_src, count 20, seconds 360; reference:url,doc.emergingthreats.net/2001972; classtype:network-scan; sid:2001972; rev:20; metadata:created_at 2010_07_30, former_category SCAN, updated_at 2017_05_11;)

### hacked to pieces
flow:to_server; flags: S,12; threshold: type both, track by_src, count 20, seconds 360; 
 - Check flow to server and check SYN flag both bit (1 and 2) (!!confused about that, meaning?!!
 - Count alerting for SYN if more then 20 counts in 360s alert it
 - Scan alert

### matched on


## ET SCAN Behavioral Unusually fast Terminal Server Traffic Potential Scan or Infection (Outbound)
alert tcp $HOME_NET any -> $EXTERNAL_NET 3389 (msg:"ET SCAN Behavioral Unusually fast Terminal Server Traffic Potential Scan or Infection (Outbound)"; flow:to_server; flags: S,12; threshold: type both, track by_src, count 20, seconds 360; reference:url,threatpost.com/en_us/blogs/new-worm-morto-using-rdp-infect-windows-pcs-082811; classtype:misc-activity; sid:2013479; rev:5; metadata:created_at 2011_08_29, former_category SCAN, updated_at 2017_05_11;)

### hacked to pieces
flow:to_server; flags: S,12; threshold: type both, track by_src, count 20, seconds 360; 
- See ET SCAN Behavioral Unusually fast Terminal Server Traffic Potential Scan or Infection (Inbound)
- Difference Home_Net talkts  to External

### matched on


## ET CINS Active Threat Intelligence Poor Reputation IP group 21
	alert ip [34.77.162.8,34.77.162.9,34.77.186.14,34.77.89.24,34.78.157.114,34.79.196.100,34.80.158.191,34.80.200.84,34.80.40.157,34.81.131.167,34.81.190.147,34.81.200.141,34.83.115.250,34.83.247.84,34.84.143.9,34.84.157.248,34.84.197.27,34.84.71.228,34.85.28.53,34.85.41.42,34.85.98.40,34.86.140.249,34.86.154.158,34.86.35.0,34.86.35.1,34.86.35.10,34.86.35.11,34.86.35.12,34.86.35.13,34.86.35.15,34.86.35.16,34.86.35.18,34.86.35.19,34.86.35.2,34.86.35.20,34.86.35.21,34.86.35.22,34.86.35.23,34.86.35.24,34.86.35.26,34.86.35.27,34.86.35.28,34.86.35.29,34.86.35.3,34.86.35.30,34.86.35.31,34.86.35.4,34.86.35.5,34.86.35.6,34.87.12.189] any -> $HOME_NET any (msg:"ET CINS Active Threat Intelligence Poor Reputation IP group 18"; reference:url,www.cinsscore.com; threshold: type limit, track by_src, seconds 3600, count 1; classtype:misc-attack; sid:2403317; rev:69123; metadata:affected_product Any, attack_target Any, deployment Perimeter, tag CINS, signature_severity Major, created_at 2013_10_08, updated_at 2021_09_28;)
### hacked to pieces
- Just a Ip Alert
### matched on


## ET POLICY Inbound RDP Connection with TLS Security Protocol Requested
alert tcp $EXTERNAL_NET any -> any 3389 (msg:"ET POLICY Inbound RDP Connection with TLS Security Protocol Requested"; flow:established,to_server; dsize:<30; content:"|00 00|"; offset:1; depth:2; content:"|e0|"; distance:2; within:1; content:"|01 00 08 00 01 00 00 00|"; within:15; fast_pattern; endswith; reference:url,medium.com/@bromiley/what-happens-before-hello-ce9f29fa0cef; classtype:bad-unknown; sid:2027412; rev:3; metadata:affected_product Windows_XP_Vista_7_8_10_Server_32_64_Bit, created_at 2019_05_31, deployment Perimeter, former_category POLICY, performance_impact Low, signature_severity Major, updated_at 2020_08_19;)

### hacked to pieces
dsize:<30; content:"|00 00|"; offset:1; depth:2;
- If the Paket size ist lower 30 bytes and the first two bytes are |00 00|

content:"|e0|"; distance:2; within:1;
- Byte (about) 5 must be |e0|  (two after first match in within 1 byte)

content:"|01 00 08 00 01 00 00 00|"; within:15; fast_pattern; endswith;
- Ends with this pattern in the last 15 bytes

### notes
Trys to (downgrade) connect with TLS. Dont know why this is an issue. Is TLS outdated?

### matched on
|bytes | data|
|-----|-------------------------------------------------|
| 0000 | 00 50 56 A5 37 A5 00 1C  7F 6D AC 1F 08 00 45 00 |
| 0016 | 00 3B 14 C6 40 00 3F 06  A7 7A C0 A8 A1 0D C1 17 |   
| 0032 | 5C AF A7 12 0D 3D D6 68  D7 D5 B0 B6 04 B6 50 18 |   
| 0048 | 00 E5 05 60 00 00 ***03 00  00 13 0E E0 00 00 00 00*** |   
| 0064 | ***00 01 00 08 00 01 00 00  00***  |



## ET POLICY Windows-Based OpenSSL Tunnel Outbound
alert tcp $HOME_NET any -> $EXTERNAL_NET any (msg:"ET POLICY Windows-Based OpenSSL Tunnel Outbound"; flow:established; content:"|16 03 00|"; content:"|00 5c|"; distance:0; content:"|c0 14 c0 0a 00 39 00 38 00 88 00 87 c0 0f c0 05 00 35 00 84 c0 12 c0 08 00 16 00 13 c0 0d c0 03 00 0a c0 13 c0 09 00 33 00 32 00 9a 00 99 00 45 00 44 c0 0e c0 04 00 2f 00 96 00 41 00 07 c0 11 c0 07 c0 0c c0 02 00 05 00 04 00 15 00 12 00 09 00 14 00 11 00 08 00 06 00 03 00 ff|"; distance:0; threshold: type both, count 1, seconds 300, track by_dst; reference:url,www.stunnel.org/download/binaries.html; classtype:policy-violation; sid:2012078; rev:5; metadata:created_at 2010_12_22, updated_at 2010_12_22;)

### hacked to pieces
content:"|16 03 00|";
content:"|00 5c|"; distance:0; 
content:"|c0 14 c0 0a 00 39 00 38 00 88 00 87 c0 0f c0 05 00 35 00 84 c0 12 c0 08 00 16 00 13 c0 0d c0 03 00 0a c0 13 c0 09 00 33 00 32 00 9a 00 99 00 45 00 44 c0 0e c0 04 00 2f 00 96 00 41 00 07 c0 11 c0 07 c0 0c c0 02 00 05 00 04 00 15 00 12 00 09 00 14 00 11 00 08 00 06 00 03 00 ff|"; distance:0; threshold: type both, count 1, seconds 300, track by_dst;

### notes
### matched on
|bytes | data|
|-----|-------------------------------------------------|
| 0000 |  00 1C 7F 6D AC 1E 00 50  56 A5 3D FD 08 00 45 00 |  
| 0016 |  00 C0 84 98 40 00 40 06  36 3E C0 A8 A1 0D C1 17 |  
| 0032 |  5C 94 B7 38 0D 3D FB D0  07 A1 9F 90 69 75 80 18 | 
| 0048 |  00 E5 AB C1 00 00 01 01  08 0A 14 12 83 1F 63 09 | 
| 0064 |  A2 3F ***16 03 00*** 00 87 01  00 00 83 03 00 61 5A 88 | 
| 0080 |  88 54 68 47 76 64 6D 74  4F 75 39 51 35 34 4C 6E | 
| 0096 |  72 78 39 30 71 4C 6D 59  57 36 35 44 63 00 ***00 5C*** |  
| 0112 |  ***C0 14 C0 0A 00 39 00 38  00 88 00 87 C0 0F C0 05*** | 
| 0128 |  ***00 35 00 84 C0 12 C0 08  00 16 00 13 C0 0D C0 03*** | 
| 0144 |  ***00 0A C0 13 C0 09 00 33  00 32 00 9A 00 99 00 45*** | 
| 0160 |  ***00 44 C0 0E C0 04 00 2F  00 96 00 41 00 07 C0 11*** | 
| 0176 |  ***C0 07 C0 0C C0 02 00 05  00 04 00 15 00 12 00 09*** | 
| 0192 |  ***00 14 00 11 00 08 00 06  00 03 00 FF*** 01 00  | 


 
## ET EXPLOIT [NCC GROUP] Possible Bluekeep Inbound RDP Exploitation Attempt (CVE-2019-0708)
alert tcp any any -> any 3389 (msg:"ET EXPLOIT [NCC GROUP] Possible Bluekeep Inbound RDP Exploitation Attempt (CVE-2019-0708)"; flow:to_server,established; content:"|03 00|"; depth:2; content:"|02 f0|"; distance:2; within:2; content:"|00 05 00 14 7c 00 01|"; within:512; content:"|03 c0|"; distance:3; within:384; content:"MS_T120|00|"; distance:6; within:372; nocase; fast_pattern; threshold: type limit, track by_src, count 2, seconds 600; reference:cve,CVE-2019-0708; reference:url,portal.msrc.microsoft.com/en-US/security-guidance/advisory/CVE-2019-0708; reference:url,github.com/nccgroup/Cyber-Defence/blob/master/Signatures/suricata/2019_05_rdp_cve_2019_0708.txt; classtype:attempted-admin; sid:2027369; rev:3; metadata:attack_target Client_and_Server, created_at 2019_05_21, deployment Perimeter, deployment Internet, deployment Internal, former_category EXPLOIT, malware_family Bluekeep, signature_severity Major, updated_at 2019_05_21;)

### hacked to pieces
### notes
### matched on

## references
- doc.emergingthreats.net/2001972
- http://www.countersnipe.com/support/cs-writing-rules.pdf
- http://books.gigatux.nl/mirror/snortids/0596006616/snortids-CHP-7-SECT-3.html
- https://www.mcafee.com/blogs/other-blogs/mcafee-labs/rdp-security-explained/
- https://bromiley.medium.com/what-happens-before-hello-ce9f29fa0cef
- https://redmine.openinfosecfoundation.org/projects/suricata/wiki/Fast_Pattern
- https://redmine.openinfosecfoundation.org/projects/suricata/wiki/Suricata_Fast_Pattern_Determination_Explained


