# Queries and Hints for Kibana
## Queries
### Time
**Out of business (depence hourOfDay Filter -> scripts)**
- ((( hourOfDay <= 23) AND (hourOfDay >= 20 )) OR ((hourOfDay >= 0 ) AND (hourOfDay <= 5)))

### Files
**Searching for Hashes (Strelka, Zeek)**
- ..
