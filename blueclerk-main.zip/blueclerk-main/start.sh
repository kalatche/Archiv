#!/bin/bash

export FLASK_APP=app/__init__.py
export FLASK_ENV=development
python3 -m flask run
