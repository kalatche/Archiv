## Others

**Out of business (depence hourOfDay Filter -> scripts)**
- ((( hourOfDay <= 23) AND (hourOfDay >= 20 )) OR ((hourOfDay >= 0 ) AND (hourOfDay <= 5)))
