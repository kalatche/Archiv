#!/usr/bin/python
# -*- coding: <encoding name> -*-
__author__ = "Daniel Fanderl"
__email__ = "daniel.fanderl@lew-verteilnetz.de"
__status__ = "Development"
__version__ = "0.0.0"


import sys
import csv
import ubuntu_lookup

#Comment
def parseListToString(unparsed_list) -> str:
    parsed_vuln_string = ""
    for entry in unparsed_list:
        parsed_vuln_string = parsed_vuln_string + ";".join(entry) + "\n"
    return parsed_vuln_string

# Comment
def writeCSV(vuln_list) -> None: 
    filename='linux_vulns.csv'

    header = ['cve','cvss3','description']
    data = vuln_list
    print(data)
    with open(filename, 'w', encoding='UTF8') as f:
        f.write(vuln_list)
        #writer = csv.writer(f)
        #writer.writerow(header)
        #writer.writerow(data)
    return 0

#Comment
def printNotices(notices) -> None: 
    for i in notices:
        print("--")
        print(i)

# Comment    
def main() -> None:
    ubuntu_notices = ubuntu_lookup.pull_ubuntu()

    parsed_ubunut_notices = parseListToString(ubuntu_notices)
    writeCSV(parsed_ubunut_notices)
    
    #printNotices(ubuntu_notices)
    return 0



if __name__ == '__main__':
    sys.exit(main())