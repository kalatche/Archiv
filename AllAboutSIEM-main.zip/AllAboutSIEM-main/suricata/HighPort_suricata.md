# Suricata for HighPort > 1024
  
## ET INFO Session Traversal Utilities for NAT (STUN Binding Request On Non-Standard High Port)
alert udp $HOME_NET any -> $EXTERNAL_NET [!3478,1023:] (msg:"ET INFO Session Traversal Utilities for NAT (STUN Binding Request On Non-Standard High Port)"; content:"|00 01|"; depth:2; content:"|21 12 a4 42|"; distance:2; within:4; reference:url,tools.ietf.org/html/rfc5389; classtype:attempted-user; sid:2033078; rev:2; metadata:created_at 2021_06_03, updated_at 2021_06_03;)

### hacked to pieces
alert udp $HOME_NET any -> $EXTERNAL_NET [!3478,1023:]
- For all Connections over 1023 except 3478 (STUN Port)

content:"|00 01|"; depth:2; 
- Message Type: 0X0001 (Binding Request)

content:"|21 12 a4 42|"; distance:2; within:4;
- Message Cookie: 2112a442 (fix value)

### notes
Find the byte sequence to identfiy STUN Requests

### matched on
|bytes | data|
|-----|-------------------------------------------------|
| 0000 | e8 d8 d1 a3 98 03 00 22 be 65 bc 00 08 00 45 00 |
| 0010 | 00 84 15 f7 00 00 7f 11 17 08 c1 17 47 99 c1 17 |
| 0020 | 44 a2 d7 7d c0 1c 00 70 98 c3 ***00 01*** 00 54 ***21 12*** |
| 0030 | ***a4 42*** fc 0f 72 21 7c 68 1d 3f 0a 44 39 1b 00 06 |
| 0040 | 00 09 32 36 6c 4d 3a 2b 59 44 46 00 00 00 00 24 |
| 0050 | 00 04 6e ff fe ff 80 29 00 08 00 00 00 00 00 03 |
| 0060 | aa 7a 80 54 00 01 31 00 00 00 80 70 00 04 00 00 |
| 0070 | 00 03 00 08 00 14 a7 be 80 7d a9 3d aa 71 5f 25 |
| 0080 | 17 9e b6 45 ed 39 54 9f 7d 5c 80 28 00 04 63 92 |
| 0090 | 20 b8 |

### STUN references
https://datatracker.ietf.org/doc/html/rfc5389
