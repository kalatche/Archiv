/****************************************************
*
*   Painless scripts to extract MS Windows Event ID
*   from raw Syslog.
*
****************************************************/

/////////////////////////////////////////////////////
// Result: double
def msg = doc['message.keyword'].value;
def eventid = 99999;
def index_str1 = msg.indexOf("Microsoft-Windows-"); //Microsoft-Windows

// debugg
eventid == -1;

if(index_str1 == -1){
    eventid = -1;
}
else{
    def index_str2 = msg.indexOf(",", index_str1); //first ,
    def index_str3 = msg.indexOf(",", index_str2+1); // second ,
    def eventstr = msg.substring(index_str2+1, index_str3);
    try{
        eventid = Integer.parseInt(eventstr);
    }
    catch(Exception e){
        eventid = -1;
    } 
}
emit(eventid)

/////////////////////////////////////////////////////
// Result: string
def msg = doc['message.keyword'].value;
def eventid = "Init";
def index_str1 = msg.indexOf("Microsoft-Windows-"); //Microsoft-Windows

if(index_str1 == -1){
    eventid = "None";
}
else{
    def index_str2 = msg.indexOf(",", index_str1); //first ,
    def index_str3 = msg.indexOf(",", index_str2+1); // second ,
    def eventstr = msg.substring(index_str2+1, index_str3);
    eventid = eventstr;
}
emit(eventid)

  /////////////////////////////////////////////////////
  // Reference:
  //
  //
  //
  //
  //
  //
