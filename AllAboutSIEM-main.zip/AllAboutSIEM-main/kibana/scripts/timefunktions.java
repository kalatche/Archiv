// extract hour of timestamp
return doc['@timestamp'].value.getHour();
